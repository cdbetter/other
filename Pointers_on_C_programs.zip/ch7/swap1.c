/*
** Exchange two integers in the calling program (doesn't work!).
*/

void
swap( int x, int y )
{
	int temp;

	temp = x;
	x = y;
	y = temp;
}
