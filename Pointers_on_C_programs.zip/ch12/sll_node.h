typedef	struct	NODE	{
	struct	NODE	*link;
	int		value;
} Node;
