typedef
struct {
	int a;
} StudentInfo;
