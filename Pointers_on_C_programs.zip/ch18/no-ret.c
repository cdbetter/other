/*
** A function that works on some machines despite a major error.
*/
int
erroneous( int a, int b )
{
	int	x;

	/*
	** Compute the answer, and return it
	*/
	x = a + b;
	return;
}
